# Third-party notices — @avinance/muvi-player

The Muvi Player SDK is proprietary (`UNLICENSED`, private). It ships with, or loads at runtime,
the open-source components below. The script-tag bundle `dist/muvi-player.global.js` includes
hls.js and @dailymotion/vast-client, so both notices must stay with that file.

| Component | Version | License | Use |
| --- | --- | --- | --- |
| [hls.js](https://github.com/video-dev/hls.js) | 1.6.19 | Apache-2.0 | HLS / LL-HLS playback over MSE |
| [@dailymotion/vast-client](https://github.com/dailymotion/vast-client-js) | 6.5.0 | MIT | VAST/VMAP parsing and VAST tracking |
| Tailwind CSS (build time only, output CSS) | 3.4.19 | MIT | `mv-`-prefixed utility CSS |

Loaded at runtime only when configured (not bundled):

| Component | When | Terms |
| --- | --- | --- |
| Google Cast Web Sender (`cast_sender.js`) | `remote.castAppId` is set | Google Cast SDK terms |
| Google Cast CAF Receiver (`apps/receiver-cast`) | on Cast receiver devices | Google Cast SDK terms |

Other workspace components (not part of this package):

| Component | Version | License | Used by |
| --- | --- | --- | --- |
| qrcode-generator | 2.0.4 | MIT | `apps/receiver-web` (QR code on the TV) |
| fastify, @fastify/static, @fastify/cors, @fastify/websocket | 5.12.8, 8.3.0, 11.4.0, 11.3.4 | MIT | `services/reference-server` |
| React, React DOM | 18.3.1 | MIT | `@avinance/muvi-player-react` (peer dependency) |
| Next.js | 14.2.35 | MIT | `apps/next-example` |

## Apache License 2.0 — hls.js

Copyright (c) 2017 Dailymotion (http://www.dailymotion.com) and hls.js contributors.
Licensed under the Apache License, Version 2.0. You may obtain a copy of the License at
http://www.apache.org/licenses/LICENSE-2.0. Unless required by applicable law or agreed to in
writing, software distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.

## MIT License — @dailymotion/vast-client

Copyright (c) 2013 Olivier Poitrey and contributors (Dailymotion).

Permission is hereby granted, free of charge, to any person obtaining a copy of this software
and associated documentation files (the "Software"), to deal in the Software without
restriction, including without limitation the rights to use, copy, modify, merge, publish,
distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions: The above copyright notice
and this permission notice shall be included in all copies or substantial portions of the
Software. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND.

Fonts: no licensed fonts are bundled. Yekan Bakh and Dubai are placeholders until the tenant
provides licensed files (see `tasks.md`, "Needs external access").
